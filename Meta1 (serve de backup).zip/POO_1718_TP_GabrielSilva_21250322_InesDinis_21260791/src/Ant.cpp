#include "Ant.h"

/* Classe base */

int Ant::counter=0;
/*Ant::Ant()
{
    //ctor
}*/



/*Ant::~Ant()
{
    //dtor
}
*/

/*  Cuidadora */

/*  Outras formigas por aqui abaixo */
