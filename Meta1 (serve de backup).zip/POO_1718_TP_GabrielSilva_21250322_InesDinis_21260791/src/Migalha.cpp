#include "Migalha.h"

Migalha::Migalha()
{
    //ctor
}

Migalha::~Migalha()
{
    //dtor
}
