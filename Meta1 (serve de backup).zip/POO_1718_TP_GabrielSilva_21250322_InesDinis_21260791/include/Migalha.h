#ifndef MIGALHA_H
#define MIGALHA_H

#include "includeme.h"

class Migalha{
  int ID;
  int energy;
  int PosX, PosY;
  public:
      Migalha();
      virtual ~Migalha();
};

#endif // MIGALHA_H
